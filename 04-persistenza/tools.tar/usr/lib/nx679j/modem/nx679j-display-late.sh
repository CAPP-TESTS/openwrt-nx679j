#!/bin/sh
# nx679j-display-late — bring-up RITARDATO di touch+display.
# Chiamato da boot-services, detached, post-rcS.
# RICETTA VERIFICATA (21/9, v76): moduli touch -> attendere il BIND del goodix
# (input nubia compare, ~15-30s) -> gap di sicurezza -> touchpaint.
# ANTI-BOOT-LOOP: marker rawdump slot 410 (DL-FIRED senza DL-CLEAN = crash
# al tentativo precedente -> skip; per riprovare azzerare lo slot 410).
# Env: DISPLAY_LATE_X (soglia uptime, default 900), DISPLAY_LATE_GAP (default 60).
X=${DISPLAY_LATE_X:-900}
GAP=${DISPLAY_LATE_GAP:-250}
LOG=/tmp/display-late.log
say() { echo "$(date +%H:%M:%S 2>/dev/null || echo t) $*" >> $LOG; tail -c 30000 $LOG 2>/dev/null > /tmp/bl411; dd if=/tmp/bl411 of=/proc/1/root/dev/rd bs=32768 seek=411 conv=sync,notrunc 2>/dev/null; }
mark() { printf '%-63s' "DL-$1" > /tmp/mk410; dd if=/tmp/mk410 of=/proc/1/root/dev/rd bs=32768 seek=410 conv=sync,notrunc 2>/dev/null; }

st=$(dd if=/proc/1/root/dev/rd bs=32768 skip=410 count=1 2>/dev/null | head -c 40)
case "$st" in
  *DL-FIRED*) case "$st" in
      *DL-CLEAN*) : ;;
      *) say "MARKER DL-FIRED senza CLEAN: tentativo precedente = crash. Skip."; exit 0 ;;
    esac ;;
esac

say "armato: attendo uptime >= $X"
N=0
while [ $N -lt 400 ]; do
  U=$(cut -d. -f1 /proc/uptime 2>/dev/null)
  [ -n "$U" ] && [ "$U" -ge "$X" ] && break
  sleep 15; N=$((N+1))
done
say "uptime $(cut -d. -f1 /proc/uptime): parto"
mark "FIRED $(cat /proc/sys/kernel/random/boot_id 2>/dev/null | head -c 8)"

mkdir -p /dev/dri /dev/input
[ -e /dev/dri/card0 ] || mknod /dev/dri/card0 c 226 0
[ -e /dev/dri/renderD128 ] || mknod /dev/dri/renderD128 c 226 128
[ -e /dev/input/event0 ] || mknod /dev/input/event0 c 13 64

M=/proc/1/root/lib/modules
for m in panel_event_notifier gpi i2c-msm-geni goodix_core; do
  if [ -e "$M/$m.ko" ]; then
    /usr/lib/nx679j/modem/finitmod "$M/$m.ko" 2>>$LOG && say "  $m ok" || say "  $m FAIL"
    sleep 2
  else
    say "  $m assente"
  fi
done

# attesa BIND goodix + fine init asincrona (esd)
B=0
while [ $B -lt 60 ]; do
  [ "$(grep -c nubia /proc/bus/input/devices 2>/dev/null)" = "1" ] && break
  sleep 5; B=$((B+1))
done
say "bind goodix: $(grep -c nubia /proc/bus/input/devices 2>/dev/null) (dopo $((B*5))s)"
# attesa fine init asincrona (esd on nel dmesg)
E=0
while [ $E -lt 60 ]; do
  dmesg | grep -q "esd on" && break
  sleep 5; E=$((E+1))
done
say "esd: $(dmesg | grep -c \"esd on\") (dopo $((E*5))s)"

# gap di sicurezza (verificato: load->bind->gap->touchpaint = OK)
sleep $GAP

# === LuCI: proto STANDARD modemmanager (2026-09-22) ===
# Dal pacchetto luci-proto-modemmanager (upstream openwrt/luci @128a7812).
# File master in /usr/lib/nx679j/modem/luci-mm (persistente); /www e' in RAM.
L=/usr/lib/nx679j/modem/luci-mm
if [ -d "$L" ]; then
  mkdir -p /www/luci-static/resources/view/modemmanager /usr/share/luci/menu.d /usr/share/rpcd/acl.d
  [ -f /www/luci-static/resources/modemmanager_helper.js ] || cp "$L/modemmanager_helper.js" /www/luci-static/resources/
  [ -f /www/luci-static/resources/protocol/modemmanager.js ] || cp "$L/modemmanager.js" /www/luci-static/resources/protocol/
  [ -f /www/luci-static/resources/view/modemmanager/status.js ] || cp "$L/view/modemmanager/status.js" /www/luci-static/resources/view/modemmanager/
  [ -f /usr/share/luci/menu.d/luci-proto-modemmanager.json ] || cp "$L/menu.json" /usr/share/luci/menu.d/luci-proto-modemmanager.json
  [ -f /usr/share/rpcd/acl.d/luci-proto-modemmanager.json ] || cp "$L/acl.json" /usr/share/rpcd/acl.d/luci-proto-modemmanager.json
  /etc/init.d/rpcd reload 2>/dev/null
  say "LuCI: proto standard modemmanager installato"
fi
# NOTA (2026-09-22): proto custom nx679j RIMOSSO -> si usa il proto STANDARD
# 'modemmanager' (netifd+MM). Vedi ricetta in skill android-boot-chain-recovery.

# === ESD KILL (2026-09-22: LA CHIAVE DEL SUCCESSO) ===
# Senza questo, ogni setcrtc/flip viene seguito da mismatch 0x0A -> esd recovery -> RESET HW.
# In questo build i modi si scrivono SUL file esd_check_mode: esd_sw_sim_success fa
# simulare SEMPRE successo al check -> niente reset -> il setcrtc passa e i pixel si vedono.
mount -t debugfs none /sys/kernel/debug 2>/dev/null
PE=/sys/kernel/debug/qcom,mdss_dsi_r6130_1080_2400_amoled_cmd
if [ -e "$PE/esd_check_mode" ]; then
  echo esd_sw_sim_success > "$PE/esd_check_mode" && say "ESD KILL ok ($PE)"
else
  say "ESD KILL: debugfs panel dir assente ($PE)"
fi

# DISPLAY: DRMTEST con hold lungo (fa setcrtc legacy + pattern; VERIFICATO 22/9:
# 'variante 0 1080x2400x90cmd: OK!' al primo colpo con ESD killato, pixel a schermo).
# Il touch resta attivo (input0): per DISEGNARE usare a mano il touchpaint.
if [ -x /usr/lib/nx679j/modem/nx679j-drmtest ]; then
  if ! pidof nx679j-drmtest >/dev/null 2>&1; then
    setsid /usr/lib/nx679j/modem/nx679j-drmtest 86400 >>$LOG 2>&1 </dev/null &
    sleep 15
    if pidof nx679j-drmtest >/dev/null 2>&1; then
      say "DISPLAY ACCESO (drmtest hold=86400)"; mark "CLEAN uptime=$(cut -d. -f1 /proc/uptime)"
    else
      say "drmtest morto (nessun crash rilevato)"; mark "CLEAN drmtest-morto"
    fi
  else
    say "drmtest gia' attivo"; mark "CLEAN gia-attivo"
  fi
fi
say "fine"
