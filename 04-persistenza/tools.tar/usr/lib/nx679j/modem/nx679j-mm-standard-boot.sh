#!/bin/sh
# nx679j-mm-standard-boot.sh — NX679J: bring up the STANDARD modemmanager
# interface once the vendor chain has completed its datapath setup.
#
# Why: chain.sh (S95, background) sets up the IPA datapath and starts a WDS
# session on the EMBEDDED data port; ModemManager can only connect after the
# chain is done AND that chain-owned WDS session has been stopped (the modem
# allows a single WDS session on the embedded port; MM creates its own).
# This script runs detached at boot:
#   1. polls /tmp/chain.log for DONE (max ~8 min, dynamic)
#   2. stops the chain-owned wds-session (pid from /tmp/wds-session.pid)
#   3. waits for the netdev rmnet_ipa0 + ModemManager to see the modem
#   4. runs ifup modem (standard proto modemmanager)
#   5. logs the result to /tmp/mm-standard-boot.log via logger
#
# Safe to re-run; if the iface is already up it does nothing.

LOG=/tmp/mm-standard-boot.log
say() { echo "[$(cut -d. -f1 /proc/uptime)] $*" >> $LOG; logger -s -t mm-standard-boot "$*"; }

# already up?
if ubus call network.interface.modem status 2>/dev/null | grep -q '"up": true'; then
	say "iface modem gia' su, nulla da fare"
	exit 0
fi

# 1) wait for chain DONE
for i in $(seq 1 96); do
	grep -q "^\[.*\] DONE" /tmp/chain.log 2>/dev/null && break
	sleep 5
done
say "chain: $(grep -c '^\[.*\] DONE' /tmp/chain.log 2>/dev/null) done-marker(s)"

# 2) stop the chain-owned wds session (frees the embedded-port WDS slot)
W=$(cat /tmp/wds-session.pid 2>/dev/null)
if [ -n "$W" ] && kill -0 "$W" 2>/dev/null; then
	kill "$W" 2>/dev/null
	say "wds-session della catena fermato (pid $W)"
else
	say "nessun wds-session della catena da fermare"
fi
sleep 3

# 3) wait for rmnet_ipa0 (chain creates it)
for i in $(seq 1 24); do
	[ -e /sys/class/net/rmnet_ipa0 ] && break
	sleep 5
done

# inject the kernel event so MM probes the modem (kobject uevents are never
# delivered on this image for runtime netdevs; the watcher does the same)
if [ -e /sys/class/net/rmnet_ipa0 ]; then
	ACTION=add DEVPATH=/devices/virtual/net/rmnet_ipa0 INTERFACE=rmnet_ipa0 \
		sh /etc/hotplug.d/net/25-modemmanager-net 2>/dev/null
	say "evento rmnet_ipa0 iniettato"

# FIX v3: al boot il probe di MM avviene PRIMA che rmnet_ipa0 esista -> il modem
# viene scartato ("couldn't find modem"). Serve un riavvio FORTE di MM DOPO l'inject:
# kill -9 + pausa 10s + start (un semplice restart e' troppo rapido: il port QRTR non si libera).
log "MM restart forte (kill + 10s + start)..."
for p in $(ps w | grep -E "[M]odemManager" | awk '{print $1}'); do kill -9 $p 2>/dev/null; done
sleep 10
/etc/init.d/modemmanager start >/dev/null 2>&1

# attesa che MM completi il probe del modem (fino a ~2.5 min)
MODEM_OK=0
for i in $(seq 1 50); do
  sleep 3
  if [ "$(mmcli -L 2>/dev/null | grep -c 'Modem/')" -ge 1 ]; then MODEM_OK=1; break; fi
done
if [ "$MODEM_OK" = 1 ]; then log "modem trovato in ModemManager"; else log "FAIL: modem non trovato in ModemManager"; exit 1; fi
fi

# wait for MM to know a modem (max 90s)
for i in $(seq 1 30); do
	mmcli -L 2>/dev/null | grep -q "Modem/" && break
	sleep 3
done

# 4) standard ifup
say "ifup modem..."
ifup modem 2>&1 | while read -r l; do say "ifup: $l"; done

# 5) result
for i in $(seq 1 40); do
	ubus call network.interface.modem status 2>/dev/null | grep -q '"up": true' && break
	sleep 3
done
if ubus call network.interface.modem status 2>/dev/null | grep -q '"up": true'; then
	IP=$(ip -4 addr show 2>/dev/null | grep -A1 qmapmux | grep inet | head -1)
	say "OK: iface modem UP ($IP)"
	ping -c 2 -W 5 1.1.1.1 >/dev/null 2>&1 && say "OK: ping 1.1.1.1" || say "WARN: ping KO"
else
	say "FAIL: iface modem non su: $(ubus call network.interface.modem status 2>/dev/null | grep code)"
fi
exit 0
