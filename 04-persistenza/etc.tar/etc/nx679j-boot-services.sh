#!/bin/sh
# nx679j-boot-services v3: attende ubus E il completamento del wifi-wrapper,
# poi lancia l'rcS. Motivo: l'rcS avviato durante il bring-up wifi (primi ~90s)
# fa crashare il SoC (reset hardware). Testato: rcS tardivo = stabile.
n=0
while [ "$n" -lt 150 ]; do
  ubus call system board >/dev/null 2>&1 && break
  sleep 2
  n=$((n+1))
done
logger -s -t procd "ubus pronto dopo $((n*2))s"
m=0
while [ "$m" -lt 150 ]; do
  if [ -f /tmp/wifi-wrapper.done ]; then break; fi
  sleep 2
  m=$((m+1))
done
if [ -f /tmp/wifi-wrapper.done ]; then
  logger -s -t procd "wifi-wrapper completato dopo $((m*2))s extra"
else
  logger -s -t procd "wifi-wrapper timeout ($((m*2))s extra), procedo"
fi
logger -s -t procd "margine sicurezza +60s prima dell'rcS"
sleep 60
if [ -f /tmp/rcs-select ]; then
  logger -s -t procd "rcS: selezione presente"
  while read s; do
    if [ -x "/etc/rc.d/$s" ]; then
      "/etc/rc.d/$s" boot
    fi
  done < /tmp/rcs-select
  logger -s -t procd "rcS: selezione completata"
else
  if [ -f /tmp/rcs-full ]; then
    logger -s -t procd "rcS: avvio completo (richiesto)"
    /etc/init.d/rcS S boot
  else
    logger -s -t procd "rcS: default sicuro (chain+MM+dbus+uhttpd)"
    for s in S50uhttpd S60dbus S70modemmanager S71mm-netlink-watch S95nx679j-modem S94nx679j-display-touch; do
      if [ -x "/etc/rc.d/$s" ]; then
        "/etc/rc.d/$s" boot
      fi
    done
    logger -s -t procd "rcS: default completato (touch/display on-demand)"
# --- launcher RITARDATO touch+display (decoupled dalla rcS; dopo la finestra instabile)
if [ ! -f /tmp/no-display-late ] && [ -x /usr/lib/nx679j/modem/nx679j-display-late.sh ]; then
  setsid /usr/lib/nx679j/modem/nx679j-display-late.sh </dev/null >/dev/null 2>&1 &
  logger -s -t procd "rcS: launcher display-late avviato (touch+display a uptime ~3000)"
fi
  fi
fi

# --- mm-standard: ifup modem standard dopo la catena (v82)
if [ -x /usr/lib/nx679j/modem/nx679j-mm-standard-boot.sh ]; then
  setsid /usr/lib/nx679j/modem/nx679j-mm-standard-boot.sh </dev/null >/dev/null 2>&1 &
  logger -s -t procd "rcS: mm-standard-boot avviato"
fi
